﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
    public class TetrisFigure
{
    public int[,] Shape { get; private set; }
    public int X { get; set; }
    public int Y { get; set; }

    public TetrisFigure(int[,] shape)
    {
        Shape = shape;
        X = 0;
        Y = 0;
    }

    public void Rotate()
    {
        int rows = Shape.GetLength(0);
        int cols = Shape.GetLength(1);
        int[,] rotatedShape = new int[cols, rows];

        for (int r = 0; r < rows; r++)
        {
            for (int c = 0; c < cols; c++)
            {
                rotatedShape[c, rows - 1 - r] = Shape[r, c];
            }
        }

        Shape = rotatedShape;
    }

    public bool IsWithinBounds(int width, int height)
    {
        for (int r = 0; r < Shape.GetLength(0); r++)
        {
            for (int c = 0; c < Shape.GetLength(1); c++)
            {
                if (Shape[r, c] == 1)
                {
                    int x = X + c;
                    int y = Y + r;
                    if (x < 0 || x >= width || y < 0 || y >= height)
                    {
                        return false;
                    }
                }
            }
        }
        return true;
    }
}
