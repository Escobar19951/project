﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    public class TetrisField
    {
        private int[,] field;

        public int Width { get; private set; }
        public int Height { get; private set; }

        public TetrisField(int width, int height)
        {
            Width = width;
            Height = height;
            field = new int[height, width];
        }

        public bool IsOccupied(int x, int y)
        {
            return field[y, x] == 1;
        }

        public void PlaceFigure(TetrisFigure figure)
        {
            for (int r = 0; r < figure.Shape.GetLength(0); r++)
            {
                for (int c = 0; c < figure.Shape.GetLength(1); c++)
                {
                    if (figure.Shape[r, c] == 1)
                    {
                        field[figure.Y + r, figure.X + c] = 1;
                    }
                }
            }
        }

        public void ClearFullRows()
        {
            for (int r = 0; r < Height; r++)
            {
                bool fullRow = true;
                for (int c = 0; c < Width; c++)
                {
                    if (field[r, c] == 0)
                    {
                        fullRow = false;
                        break;
                    }
                }

                if (fullRow)
                {
                    for (int rr = r; rr > 0; rr--)
                    {
                        for (int cc = 0; cc < Width; cc++)
                        {
                            field[rr, cc] = field[rr - 1, cc];
                        }
                    }
                    for (int cc = 0; cc < Width; cc++)
                    {
                        field[0, cc] = 0;
                    }
                }
            }
        }

        public void Draw()
        {
            Console.Clear();
            for (int r = 0; r < Height; r++)
            {
                for (int c = 0; c < Width; c++)
                {
                    if (field[r, c] == 1)
                    {
                        Console.Write("#");
                    }
                    else
                    {
                        Console.Write(".");
                    }
                }
                Console.WriteLine();
            }
        }
    }
