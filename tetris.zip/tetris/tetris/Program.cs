﻿using System;
using System.Threading;

class Program
{
    static void Main(string[] args)
    {
        TetrisField field = new TetrisField(10, 10);
        TetrisFigure currentFigure = new TetrisFigure(new int[,] {
            { 1, 1, 1, 1 }
        });

        currentFigure.X = field.Width / 2 - currentFigure.Shape.GetLength(1) / 2;

        bool gameOver = false;

        while (!gameOver)
        {
            // Обработка ввода игрока
            if (Console.KeyAvailable)
            {
                var key = Console.ReadKey(true).Key;
                if (key == ConsoleKey.LeftArrow)
                {
                    currentFigure.X--;
                    if (!currentFigure.IsWithinBounds(field.Width, field.Height) || CheckCollision(field, currentFigure))
                    {
                        currentFigure.X++;
                    }
                }
                if (key == ConsoleKey.RightArrow)
                {
                    currentFigure.X++;
                    if (!currentFigure.IsWithinBounds(field.Width, field.Height) || CheckCollision(field, currentFigure))
                    {
                        currentFigure.X--;
                    }
                }
                if (key == ConsoleKey.DownArrow)
                {
                    currentFigure.Y++;
                    if (!currentFigure.IsWithinBounds(field.Width, field.Height) || CheckCollision(field, currentFigure))
                    {
                        currentFigure.Y--;
                    }
                }
                if (key == ConsoleKey.UpArrow)
                {
                    currentFigure.Rotate();
                    if (!currentFigure.IsWithinBounds(field.Width, field.Height) || CheckCollision(field, currentFigure))
                    {
                        currentFigure.Rotate(); // Rotate back
                        currentFigure.Rotate();
                        currentFigure.Rotate();
                    }
                }
            }

            // Обновление состояния игры
            currentFigure.Y++;
            if (!currentFigure.IsWithinBounds(field.Width, field.Height) || CheckCollision(field, currentFigure))
            {
                currentFigure.Y--;
                field.PlaceFigure(currentFigure);
                field.ClearFullRows();
                currentFigure = new TetrisFigure(new int[,] {
                    { 1, 1, 1, 1 }
                });
                currentFigure.X = field.Width / 2 - currentFigure.Shape.GetLength(1) / 2;
                currentFigure.Y = 0;

                if (CheckCollision(field, currentFigure))
                {
                    gameOver = true;
                }
            }

            // Отрисовка поля
            field.Draw();
            DrawFigure(field, currentFigure);
            Thread.Sleep(500);
        }

        Console.WriteLine("Game Over");
    }

    static bool CheckCollision(TetrisField field, TetrisFigure figure)
    {
        for (int r = 0; r < figure.Shape.GetLength(0); r++)
        {
            for (int c = 0; c < figure.Shape.GetLength(1); c++)
            {
                if (figure.Shape[r, c] == 1)
                {
                    int x = figure.X + c;
                    int y = figure.Y + r;
                    if (x < 0 || x >= field.Width || y < 0 || y >= field.Height || field.IsOccupied(x, y))
                    {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    static void DrawFigure(TetrisField field, TetrisFigure figure)
    {
        for (int r = 0; r < figure.Shape.GetLength(0); r++)
        {
            for (int c = 0; c < figure.Shape.GetLength(1); c++)
            {
                if (figure.Shape[r, c] == 1)
                {
                    int x = figure.X + c;
                    int y = figure.Y + r;
                    if (x >= 0 && x < field.Width && y >= 0 && y < field.Height)
                    {
                        Console.SetCursorPosition(x, y);
                        Console.Write("#");
                    }
                }
            }
        }
    }
}